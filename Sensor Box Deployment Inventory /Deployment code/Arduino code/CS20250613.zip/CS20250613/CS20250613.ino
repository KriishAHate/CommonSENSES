#include "arduino_secrets.h"

//**************************************
//V20250508 do:
//1. Sample data from sensors every 1 minute
//2. Log sensor data to SD card and upload to cloud via LTE module every 15 minutes (15 samples)
//3. Count how much time it takes for the LTE module to upload data every round and log and upload the time with the sensor data. Removed in V20250604
//4. Log error messages to SD card
//5. Add uploading error message to cloud and log to SD
//6. error message lookup table: 
  //Error Number | Error Description
  //E1           | Serial Port not open
  //E2           | T&RH sensor not found
  //E3           | RTC not found
  //E4           | LTE module connection to cloud timeout
  //E5           | LTE module receiving data from Arduino timeout
  //E6           | SD module failure
  //E7           | Buffer overflow
  //E8           | SD open file failure
  //E9           | SD Error logging failure
  //E10          | ADC not found
//7. add ADC module

//V20250604 change:
//1. Added Box ID to the sample data uploaded

//V20250606 change:
//1. Put Box ID to EEPROM
//2. Added Month and Date to the data uploaded

//V20250606_2 change:
//1. Added Box ID to data file name that saved to SD card
//2. Added code to send error message to LTE when SD fails to log data or error message
//3. Added time stamp to the error message to be uploaded to LTE

//V20250610 change:
//1. Added ADC module error message
//2. Added Box ID to the error messages
//3. Added LTE setup message uploading

//V20250612 change:
//1. Changed errorMessage[] and Message[] from local variable to global variable

//V20250613 change:
//1. Power LTE module on inside isLTEready(), power LTE module off inside isLTEreceived(), power SD module on inside isSDready(), power SD module off inside write2SD() and LogError(). Put all the LTE module turn on and off code inside the functions instead of outside of the functions to make sure everytime we call the isLTEready(), isSDready() and so on, the MOSFESTs have already been turn on properly. And after we call isLTEreceived() function and so on, we will turn off the MOSFETS properly. Also it makes it neat inside the loop().
//2. Reorganized the if structure in loop(), to make sure the action flow in the loop() more clear, to make sure the two SD files open and close will not coflict with each other.
//3. Save the error message in the data file too. Do not create a new file for error message? This is only an idea. Did not change this part in this version.

//Note:
//1. After turning on the SD module, you should use SD.begin() to start the SD module. For LTE module no initiallization is needed.
//2. When the RTC is missing, the logError() cannot get RTC time, so the time will be wrong, but the error code will be correct.
//3. T&RH sensor need 5 seconds to setup
//4. Without error menage, if T&RH sensor missing, T_RH.read() function will stuck the whole program
//5. Noise dB = ADC reading / ADC max value * voltage reference * 50, where ADC max value = 32768.0, voltage reference = 6.14
//
//Ruifeng Song 06/13/2025
//**************************************

// Libraries
#include <Wire.h> // For I2C communication
#include <RTClib.h> // For RTC module
#include <SD.h> // For SD module
#include "AM2315C.h" // For T&RH sensor
#include <Adafruit_ADS1X15.h> // For ADC, convert noise sensor analog signal to digital
#include <EEPROM.h> // Get Box ID from EEPROM

// Pin Definitions
#define MOSFET_LTE 7
#define MOSFET_SD 8
#define BUFFER_SIZE 52 // 15 readings * 3 data points per reading + 4 data points for date&time + Box ID

#define sampleNum 15 // log and upload after collecting 15 samples
#define interval 60000 // Sensor sampling interval in milliseconds (60,000 ms = 1 minute)
#define delayTime 1000 // Set delay_time to be 1 second
#define LTE_conn_time 120 // LTE connection timeout 120 seconds
#define LTE_recv_time 20 // LTE data receiving timeout 20 seconds
#define SD_open_time 10 // SD_module open_file timeout 10 seconds
#define ErrorNum 9999 // Error number for T&RH sensor
#define T_RH_setup_time 5000 // 5 seconds to_setup T&RH sensor
#define one_minute 60000

// Global Variables
RTC_DS3231 rtc;
Adafruit_ADS1115 ads1115; // Create ADC instance
File myFile; // Data file in SD
File errorFile; // Error file in SD
char filename[13]; // 8 for name + 1 for the dot + 3 for the extension + 1 for the null terminator
AM2315C T_RH; // T&RH sensor
int buffer[BUFFER_SIZE]; // Buffer to store integer data
int bufferIndex = 0;     // Tracks the next position to put data in the buffer
int year, month, day, hour, minute;
int temp, hum, dbValue;

const char CharComma = ',';  // Define CharComma as a comma character
const char Semicolon = ';';  // Define Semicolon as a semicolon character
const char LTEreadyMark = '$'; // LTE will send this mark when it connected to cloud and ready to get message
const char LTEreceivedMark = '#'; // LTE will send this mark when cloud successfully received the whole message
unsigned int delayCount = 0;  // Variable to count duration of each part

int Box_ID;  // Box ID

void setup() {
  pinMode(MOSFET_LTE, OUTPUT);
  pinMode(MOSFET_SD, OUTPUT);
  digitalWrite(MOSFET_LTE, LOW);
  digitalWrite(MOSFET_SD, LOW);

  Serial.begin(9600); // LTE and Arduino are using Serial port for communication

  // We did not check the initialization here because we will check status for all the sensors later
  // Initialize Sensors
  Wire.begin();
  T_RH.begin();
  delay(T_RH_setup_time); // For T&RH sensor to setup

  // Initialize RTC
  rtc.begin();

  // Initialize ADC
  ads1115.begin();

  Box_ID = EEPROM.read(0); // Get Box ID

  arePartsReady(); // Check serial port, T&RH sensor, ADC module, and RTC. Need this to make sure RTC pass right time to LTE_setup_message()

  // Send message to LTE module every time after reboot
  LTE_setup_message();
  
}//end setup()

void loop() {
  // Collect N = sampleNum readings
  collectSamples();

  bool lteStatus = isLTEready();  // Check LTE status first
  bool sdStatus = isSDready();    // Then check SD status

  if (lteStatus && sdStatus) {
    // Case 1: LTE OK, SD OK
    Data2Cloud();
    isLTEreceived();
    write2SD();
  } else if (lteStatus && !sdStatus) {
    // Case 2: LTE OK, SD FAIL
    Data2Cloud();
    Error2Cloud(6);  // E6: SD module failure
    isLTEreceived();
  } else if (!lteStatus && sdStatus) {
    // Case 3: LTE FAIL, SD OK
    write2SD();
    logError(4);  // E4: LTE module connection timeout
  } else {
    // Case 4: LTE FAIL, SD FAIL -> Do nothing and restart loop
  } // End else{}

  bufferIndex = 0;  // Reset buffer for next batch
} // End loop()

void updateDT() {
  DateTime now = rtc.now();
  year = now.year();
  year = year % 100;
  hour = now.hour();
  minute = now.minute();
  month = now.month();
  day = now.day();
}//end updateDT()

int readTemperatureOne() {
  T_RH.read();
  int temp = round(T_RH.getTemperature() * 100); // The sensor output data with two decimal digits, keep the digits and convert to int
  return isnan(temp) ? ErrorNum : temp; // Handle invalid data
}//end readTemperatureOne()

int readHumidity() {
  T_RH.read();
  int hum = round(T_RH.getHumidity() * 100); // Same as above
  return isnan(hum) ? ErrorNum : hum; // Handle invalid data
}//end readHumidity()

int readSound() {
  int voltageValue = ads1115.readADC_SingleEnded(0);
  return voltageValue;
}//end readSound()

void getFileName() {
  
  updateDT();
  sprintf(filename, "%02d%02d%02d%02d.txt", Box_ID, year, month, day);
  
}//end getFileName()

void updateData() {
  updateDT();
  temp = readTemperatureOne();
  hum = readHumidity();
  dbValue = readSound();
}//end updateData()

void appendToBuffer() {
  // Ensure bufferIndex does not exceed the buffer size
  if (bufferIndex + 5 <= BUFFER_SIZE) { // Updated to account for new parameters
    if (bufferIndex == 0) { // Only append date and time on the first entry
      buffer[bufferIndex++] = Box_ID;
      buffer[bufferIndex++] = month;
      buffer[bufferIndex++] = day;
      buffer[bufferIndex++] = hour;
      buffer[bufferIndex++] = minute;
    }//end if()
    buffer[bufferIndex++] = temp;
    buffer[bufferIndex++] = hum;
    buffer[bufferIndex++] = dbValue;
  } else {
    digitalWrite(MOSFET_SD, HIGH);
    digitalWrite(MOSFET_LTE, HIGH);
    isLTEready();
    Error2Cloud(7);
    isLTEreceived();
    
    isSDready();
    logError(7); // Log E7: Buffer overflow
  }//end else()
}//end appendToBuffer()

void collectSamples() {
  // Collect N = sampleNum readings
  for (int readingCount = 0; readingCount < sampleNum; readingCount++) {
    // Update data and store it
    updateData();
    appendToBuffer();
    // Time interval between each reading
    delay(interval);
  }//end for()
} // End collectSamples()

void write2SD() {
  getFileName(); // Call to update the filename

  myFile = SD.open(filename, FILE_WRITE);
  if (myFile) {
    // Write all the data in the buffer as a single line, separated by comma
    for (int i = 0; i < bufferIndex; i++) {
      myFile.print(CharComma); // Add comma to seperate each value
      myFile.print(buffer[i]);
    }//end for()

    myFile.println();
    myFile.close();
  } else {
    isLTEready();
    Error2Cloud(8);  // Log E8: SD open file failure
    isLTEreceived();
  }//end else()
}//end write2SD()

//*** define a logError() function to log error messages to SD card. file name should be 'ErrorLog.txt'. every error message should start with date time stamp into minute will be sufficient not need to be accurate to seconds
// Function to log error messages to SD card
void logError(int ErrorCode) {
  updateDT();
  char errorMessage[20]; // Error message to log in SD or upload to LTE
  sprintf(errorMessage, "%02d%02d%02d%02d %02d:%02d E%02d", 
          Box_ID, year, month, day, hour, minute, ErrorCode);

  errorFile = SD.open("ErrorLog.txt", FILE_WRITE);
  if (errorFile) {
    errorFile.println(errorMessage);
    errorFile.close();
  } else {
    isLTEready();
    Error2Cloud(9); // Log E9: SD Error file open failure
    isLTEreceived();
  }//end else()
}//end logError()

void Data2Cloud() {
  if (bufferIndex == 0) return; // No data to send

  // Send all the data in the buffer as a single line, separated by comma
  for (int i = 0; i < bufferIndex; i++) {
    Serial.flush();
    Serial.print(CharComma); // Add comma to seperate each value
    Serial.print(buffer[i]);
  }//end for() 
  
  Serial.println(Semicolon); // End of data indication
}//end Data2Cloud()

void Error2Cloud(int ErrorCode) {
  updateDT();
  char errorMessage[20]; // Error message to log in SD or upload to LTE
  sprintf(errorMessage, "%02d%02d%02d%02d %02d:%02d E%02d", 
          Box_ID, year, month, day, hour, minute, ErrorCode);
  Serial.flush();
  Serial.print(errorMessage);
  Serial.println(Semicolon); // End of sending indication
} // End Error2Cloud()

bool isLTEready() {
  digitalWrite(MOSFET_LTE, HIGH); // Power on the LTE module
  // Check if the LTE is ready after turn it on
  // Wait until receive LTEreadyMark from serial port, timeout after 120 seconds
  delayCount = 0;  // Initial the count
  while (delayCount < LTE_conn_time) {
    if (Serial.available() > 0) {
      char receivedChar = Serial.read(); // Read one byte of the incoming character
      if (receivedChar == LTEreadyMark) { // LTE module will send LTEreadyMark (start) when it is ready to receive data
        Serial.flush();
        return true;  // LTE is ready
      }//end if()
    }//end if()
    delay(delayTime);  // Short delay to avoid overwhelming the serial buffer
    delayCount++;
  }//end while

  // Timeout error for LTE communication
  Serial.flush();
  return false; // LTE connecting timeout
} // End isLTEready()

bool isLTEreceived() {
  // Check if the cloud successfully received data
  // Wait until receive "#" from serial port, then turn them off
  delayCount = 0;  // Initial the count
  while (delayCount < LTE_recv_time) {  // Timeout after 20 seconds
    if (Serial.available() > 0) {
      char receivedChar = Serial.read();  // Read the incoming character
      if (receivedChar == LTEreceivedMark) { // when the LTE is done publishing data to the cloud, it will feedback a LTEreceivedMark (end)
        Serial.flush();
        digitalWrite(MOSFET_LTE, LOW); // Power off the LTE module
        return true;  // return true once we have received LTEreceivedMark, meaning the cloud received whole message
      }//end if()
    }//end if()
    delay(delayTime);  // Help to define the timeout for receiving
    delayCount++;
  }//end while

  // Timeout error for LTE response, cloud fail to receive whole message, return false
  Serial.flush();
  digitalWrite(MOSFET_LTE, LOW); // Power off the LTE module
  return false; // LTE receiveing timeout
} // End isLTEreceived()

bool isSDready() {
  digitalWrite(MOSFET_SD, HIGH); // Power on the SD module
  // Check if the SD module is ready
  // Wait until SD module is ready, timeout after 10 seconds
  delayCount = 0;  // Initial the count
  while (!SD.begin()) {
    if (delayCount > SD_open_time) {
      return false;  // Exit if SD module is not ready within 10 seconds, SD timeout
    }//end if()
    delay(delayTime);  // Short delay before trying again
    delayCount++;
  }//end while

  return true; // SD module is ready
} // End isSDready()

void arePartsReady() {
  if (!Serial) {
    isLTEready();
    Error2Cloud(1);
    isLTEreceived();
    
    isSDready();
    logError(1);      // E1: Serial Port not open
  }//end if()

  // Initialize RTC
  if (!rtc.begin()) {
    isLTEready();
    Error2Cloud(3);
    isLTEreceived();
    
    isSDready();
    logError(3);      // E3: RTC not found
  }//end if()

  // ***if the T&RH sensor fail to open write the error message to SD
  if (!T_RH.begin()){
    isLTEready();
    Error2Cloud(2);
    isLTEreceived();
    
    isSDready();
    logError(2);      // E2: T&RH sensor not found
  }//end if()

  if (!ads1115.begin()){
    isLTEready();
    Error2Cloud(10);
    isLTEreceived();
    
    isSDready();
    logError(10);      // E10: ADC not found
  }//end if()

} // End arePartsReady()

void LTE_setup_message(){
  isLTEready();
  updateDT();
  char Message[32]; // LTE setup message to be uploaded
  sprintf(Message, "%02d%02d%02d%02d %02d:%02d LTE Setup Done", 
          Box_ID, year, month, day, hour, minute);
  Serial.flush();
  Serial.print(Message);
  Serial.println(Semicolon); // End of sending indication
  isLTEreceived();
} // End LTE_setup_message()